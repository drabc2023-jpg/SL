// ============================================
// GAMES — Memory Match & Word Quiz
// ============================================

// ── MEMORY MATCH ──
const emojis = ['🌸','🍃','🦋','🌺','🍀','🌻','🐝','🌈'];
let cards = [...emojis, ...emojis];
let flipped = [], matched = 0, moves = 0, lockBoard = false;

function shuffle(arr) {
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function initMemory() {
  const board = document.getElementById('memoryBoard');
  if (!board) return;
  board.innerHTML = '';
  flipped = []; matched = 0; moves = 0; lockBoard = false;
  document.getElementById('moveCount').textContent = '0';
  const shuffled = shuffle([...cards]);

  shuffled.forEach((emoji, i) => {
    const card = document.createElement('div');
    card.className = 'memory-card';
    card.dataset.emoji = emoji;
    card.dataset.index = i;
    card.textContent = '?';
    card.onclick = () => flipCard(card);
    board.appendChild(card);
  });
}

function flipCard(card) {
  if (lockBoard || card.classList.contains('flipped') || card.classList.contains('matched')) return;
  card.textContent = card.dataset.emoji;
  card.classList.add('flipped');
  flipped.push(card);

  if (flipped.length === 2) {
    moves++;
    document.getElementById('moveCount').textContent = moves;
    lockBoard = true;
    const [a, b] = flipped;
    if (a.dataset.emoji === b.dataset.emoji) {
      a.classList.add('matched'); b.classList.add('matched');
      matched++;
      flipped = []; lockBoard = false;
      if (matched === emojis.length) {
        setTimeout(() => showToast(`🎉 Selesai dalam ${moves} langkah! Hebat!`), 300);
      }
    } else {
      setTimeout(() => {
        a.textContent = '?'; b.textContent = '?';
        a.classList.remove('flipped'); b.classList.remove('flipped');
        flipped = []; lockBoard = false;
      }, 900);
    }
  }
}

// ── WORD QUIZ ──
const quizData = [
  { hint: 'Makhluk hidup yang bisa terbang dan bertelur', answer: 'BURUNG', letters: 'BUGRNUI' },
  { hint: 'Buah tropis berwarna kuning yang melengkung', answer: 'PISANG', letters: 'PIGSNA' },
  { hint: 'Bintang yang selalu muncul di siang hari', answer: 'MATAHARI', letters: 'AMAHITAR' },
  { hint: 'Tempat menyimpan uang dan menabung', answer: 'BANK', letters: 'BNKAA' },
  { hint: 'Hewan peliharaan yang suka mengeong', answer: 'KUCING', letters: 'KUNGIC' },
  { hint: 'Sayuran hijau berbentuk pohon kecil', answer: 'BROKOLI', letters: 'BKOILOR' },
  { hint: 'Alat musik yang dipetik senarnya', answer: 'GITAR', letters: 'GITRAA' },
  { hint: 'Warna langit saat cerah', answer: 'BIRU', letters: 'BIURAJ' },
  { hint: 'Minuman hangat dari daun teh', answer: 'TEH', letters: 'TEHSI' },
  { hint: 'Orang yang mengobati orang sakit', answer: 'DOKTER', letters: 'DKTORE' },
];

let currentQuiz = 0;

function renderQuiz() {
  const q = quizData[currentQuiz];
  document.getElementById('quizHint').textContent = q.hint;
  document.getElementById('quizAnswer').value = '';
  document.getElementById('quizResult').textContent = '';
  document.getElementById('quizResult').className = 'quiz-result';

  const lettersEl = document.getElementById('quizLetters');
  lettersEl.innerHTML = '';
  shuffle([...q.letters]).forEach(l => {
    const span = document.createElement('span');
    span.textContent = l;
    lettersEl.appendChild(span);
  });
}

function checkQuiz() {
  const answer = document.getElementById('quizAnswer').value.toUpperCase().trim();
  const correct = quizData[currentQuiz].answer;
  const resultEl = document.getElementById('quizResult');
  if (answer === correct) {
    resultEl.textContent = '✅ Benar! Bagus sekali!';
    resultEl.className = 'quiz-result benar';
    showToast('🎉 Jawaban benar!');
  } else {
    resultEl.textContent = `❌ Kurang tepat. Coba lagi!`;
    resultEl.className = 'quiz-result salah';
  }
}

function nextQuiz() {
  currentQuiz = (currentQuiz + 1) % quizData.length;
  renderQuiz();
}

// ── INIT ON LOAD ──
document.addEventListener('DOMContentLoaded', () => {
  initMemory();
  renderQuiz();
});
