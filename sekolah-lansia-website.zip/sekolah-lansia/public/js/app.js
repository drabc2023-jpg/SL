// ============================================
// SEKOLAH LANSIA BAHAGIA — MAIN APP JS
// ============================================

// ── SITE CONFIG (loaded from localStorage / admin) ──
let siteConfig = JSON.parse(localStorage.getItem('siteConfig') || 'null') || {
  siteName: 'Sekolah Lansia Bahagia',
  brandText: 'Sekolah Lansia',
  tagline: 'Bersama menuju hari tua yang bermakna, bahagia, dan penuh kasih sayang.',
  heroBadge: '✦ Bersama Lebih Bermakna ✦',
  heroTitle: 'Sekolah Lansia<br><em>Bahagia</em>',
  heroSubtitle: 'Tempat belajar, berkreasi, dan berbagi kebahagiaan<br>bagi para lansia tercinta',
  sambutanTeks: 'Selamat datang di Sekolah Lansia Bahagia — tempat di mana setiap langkah usia adalah anugerah yang patut disyukuri dan dirayakan bersama. Kami hadir untuk memastikan masa senja Anda dipenuhi dengan pembelajaran, kebersamaan, dan kebahagiaan sejati.',
  kepalaNama: 'Dr. Siti Rahayu, M.Kes',
  kepalaJabatan: 'Kepala Sekolah Lansia Bahagia',
  visiTeks: 'Menjadi pusat pembelajaran dan pemberdayaan lansia yang terdepan, menciptakan generasi senior yang aktif, sehat, bahagia, dan bermartabat di Indonesia.',
  alamatTeks: 'Jl. Sejahtera No. 45, Kelurahan Damai, Kecamatan Bahagia, Jakarta Selatan 12345',
  teleponTeks: '+62 21 555-666',
  emailTeks: 'info@sekolahlansia.id',
  jamTeks: 'Senin – Sabtu: 07.00 – 15.00 WIB',
  igLink: 'https://instagram.com/',
  ytLink: 'https://youtube.com/',
  waLink: 'https://wa.me/6221555666',
  fbLink: 'https://facebook.com/',
  emailLink: 'mailto:info@sekolahlansia.id',
  primaryColor: '#2E7D5B',
  goldColor: '#C8962A',
  theme: 'green'
};

function applyConfig() {
  const s = siteConfig;
  // Apply colors
  document.documentElement.style.setProperty('--primary', s.primaryColor);
  document.documentElement.style.setProperty('--gold', s.goldColor);

  const set = (id, val, prop = 'innerHTML') => {
    const el = document.getElementById(id);
    if (el) el[prop] = val;
  };

  set('site-title', s.siteName + ' — Bersama Menuju Hari Tua Yang Bermakna');
  set('nav-brand-text', s.brandText);
  set('hero-badge', s.heroBadge);
  set('hero-title', s.heroTitle);
  set('hero-subtitle', s.heroSubtitle);
  set('sambutan-teks', s.sambutanTeks);
  set('kepala-nama', s.kepalaNama);
  set('kepala-jabatan', s.kepalaJabatan);
  set('visi-teks', s.visiTeks);
  set('alamat-teks', s.alamatTeks);
  set('telepon-teks', `<a href="tel:${s.teleponTeks.replace(/\s/g,'')}">${s.teleponTeks}</a>`);
  set('email-teks', `<a href="mailto:${s.emailTeks}">${s.emailTeks}</a>`);
  set('jam-teks', s.jamTeks);
  set('footer-tagline', s.tagline);
  set('footer-nama', s.siteName);
  set('footer-logo-text', s.brandText.replace(' ', '<br>') + '<br><em>Bahagia</em>');

  // Social links
  const setHref = (id, href) => { const el = document.getElementById(id); if(el) el.href = href; };
  setHref('ig-link', s.igLink); setHref('yt-link', s.ytLink);
  setHref('wa-link', s.waLink); setHref('email-link', s.emailLink);
  setHref('yt-channel-link', s.ytLink);
  setHref('f-ig', s.igLink); setHref('f-yt', s.ytLink);
  setHref('f-wa', s.waLink); setHref('f-fb', s.fbLink); setHref('f-email', s.emailLink);
}

// ── NAVBAR ──
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  navbar.classList.toggle('scrolled', window.scrollY > 50);
});

function toggleMenu() {
  document.getElementById('navLinks').classList.toggle('open');
}
document.querySelectorAll('.nav-links a').forEach(a => {
  a.addEventListener('click', () => document.getElementById('navLinks').classList.remove('open'));
});

// ── SCROLL ANIMATIONS ──
const observer = new IntersectionObserver((entries) => {
  entries.forEach(e => {
    if (e.isIntersecting) {
      e.target.style.opacity = '1';
      e.target.style.transform = 'translateY(0)';
    }
  });
}, { threshold: 0.1 });

document.querySelectorAll('.program-card, .agenda-item, .di-card, .yt-card, .game-card').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(30px)';
  el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  observer.observe(el);
});

// ── VISI MISI TABS ──
function switchTab(tab) {
  document.querySelectorAll('.vm-tab').forEach((t, i) => {
    const tabs = ['visi','misi','nilai'];
    t.classList.toggle('active', tabs[i] === tab);
  });
  document.querySelectorAll('.vm-panel').forEach(p => p.classList.remove('active'));
  document.getElementById('tab-' + tab).classList.add('active');
}

// ── GALLERY FILTER ──
function filterGallery(cat) {
  document.querySelectorAll('.gf-btn').forEach(b => b.classList.remove('active'));
  event.target.classList.add('active');
  document.querySelectorAll('.gallery-item').forEach(item => {
    const show = cat === 'all' || item.dataset.cat === cat;
    item.style.display = show ? '' : 'none';
    item.style.opacity = show ? '1' : '0';
  });
}

// ── LIGHTBOX ──
let currentPhoto = 0;
const photoCount = 6;
function openLightbox(idx) {
  currentPhoto = idx;
  document.getElementById('lightbox').classList.add('open');
  document.body.style.overflow = 'hidden';
}
function closeLightbox() {
  document.getElementById('lightbox').classList.remove('open');
  document.body.style.overflow = '';
}
function changePhoto(dir) {
  currentPhoto = (currentPhoto + dir + photoCount) % photoCount;
}

// ── ABSENSI ──
const today = new Date();
document.getElementById('today-date').textContent = today.toLocaleDateString('id-ID', {
  weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'
});

function submitAbsensi() {
  const nama = document.getElementById('abs-nama').value.trim();
  const nomor = document.getElementById('abs-nomor').value.trim();
  const kegiatan = document.getElementById('abs-kegiatan').value;
  const health = document.querySelector('input[name="health"]:checked')?.value;

  if (!nama || !nomor) return showToast('⚠️ Nama dan nomor anggota wajib diisi!');

  const absList = JSON.parse(localStorage.getItem('absensi') || '[]');
  const record = {
    id: Date.now(),
    nama, nomor, kegiatan, health,
    waktu: new Date().toISOString(),
    tanggal: today.toISOString().split('T')[0]
  };
  absList.push(record);
  localStorage.setItem('absensi', JSON.stringify(absList));

  // Update UI
  const count = absList.filter(a => a.tanggal === record.tanggal).length;
  document.getElementById('hadir-count').textContent = count;

  const listEl = document.getElementById('abs-recent');
  const newItem = document.createElement('div');
  newItem.className = 'abs-item';
  newItem.innerHTML = `<i class="fas fa-user-circle"></i> ${nama} — Hadir`;
  listEl.prepend(newItem);

  document.getElementById('abs-nama').value = '';
  document.getElementById('abs-nomor').value = '';
  showToast('✅ Absensi berhasil dicatat!');
}

// ── PENDAFTARAN ──
function nextStep(n) {
  if (n === 2) {
    const nama = document.getElementById('reg-nama').value.trim();
    const telp = document.getElementById('reg-telp').value.trim();
    if (!nama || !telp) return showToast('⚠️ Nama dan telepon wajib diisi!');
  }
  if (n === 'success') return submitFinal();
  document.querySelectorAll('.step-content').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.step').forEach((s, i) => s.classList.toggle('active', i + 1 === n));
  const el = document.getElementById('step-' + n);
  if (el) el.classList.add('active');
}

function submitRegistrasi() {
  if (!document.getElementById('setuju').checked) return showToast('⚠️ Centang persetujuan terlebih dahulu!');

  const regNum = 'SLB-' + new Date().getFullYear() + '-' + String(Date.now()).slice(-4);
  const regData = {
    id: regNum,
    nama: document.getElementById('reg-nama').value,
    email: document.getElementById('reg-email').value,
    telp: document.getElementById('reg-telp').value,
    tgl: Date.now()
  };

  const regs = JSON.parse(localStorage.getItem('registrasi') || '[]');
  regs.push(regData);
  localStorage.setItem('registrasi', JSON.stringify(regs));

  document.querySelectorAll('.step-content').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.step').forEach(s => s.classList.add('active'));
  document.getElementById('step-success').classList.add('active');
  document.getElementById('reg-num').textContent = regNum;
}

function resetForm() {
  document.querySelectorAll('.step-content').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.step').forEach((s, i) => s.classList.toggle('active', i === 0));
  document.getElementById('step-1').classList.add('active');
  document.getElementById('reg-nama').value = '';
  document.getElementById('reg-email').value = '';
  document.getElementById('reg-telp').value = '';
}

// ── CHAT ──
const chatResponses = [
  'Terima kasih sudah menghubungi kami! 😊 Ada yang bisa kami bantu?',
  'Untuk informasi pendaftaran, silakan scroll ke bagian "Daftar Sekarang" di halaman ini.',
  'Jadwal kegiatan dapat dilihat di bagian Agenda. Kami aktif Senin–Sabtu jam 07.00–15.00.',
  'Bisa juga hubungi kami via WhatsApp untuk respons lebih cepat ya! 📱',
  'Terima kasih atas pertanyaannya. Tim kami akan segera membantu Anda!'
];
let chatIdx = 0;

function toggleChat() {
  const w = document.getElementById('chatWidget');
  w.classList.toggle('open');
  document.querySelector('.chat-badge').style.display = 'none';
}

function sendChat() {
  const input = document.getElementById('chatInput');
  const msg = input.value.trim();
  if (!msg) return;

  const msgs = document.getElementById('chatMessages');
  const userDiv = document.createElement('div');
  userDiv.className = 'msg user';
  userDiv.innerHTML = `<div class="msg-bubble">${msg}</div>`;
  msgs.appendChild(userDiv);
  input.value = '';

  setTimeout(() => {
    const botDiv = document.createElement('div');
    botDiv.className = 'msg bot';
    botDiv.innerHTML = `<div class="msg-bubble">${chatResponses[chatIdx % chatResponses.length]}</div>`;
    msgs.appendChild(botDiv);
    msgs.scrollTop = msgs.scrollHeight;
    chatIdx++;
  }, 800);
  msgs.scrollTop = msgs.scrollHeight;
}

// ── TOAST ──
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// ── COUNTER ANIMATION ──
function animateCounters() {
  document.querySelectorAll('.stat-n').forEach(el => {
    const target = parseInt(el.textContent);
    if (isNaN(target)) return;
    let count = 0;
    const step = target / 60;
    const interval = setInterval(() => {
      count = Math.min(count + step, target);
      el.textContent = Math.floor(count) + (el.textContent.includes('+') ? '+' : '');
      if (count >= target) clearInterval(interval);
    }, 30);
  });
}

const heroObserver = new IntersectionObserver(entries => {
  if (entries[0].isIntersecting) { animateCounters(); heroObserver.disconnect(); }
}, { threshold: 0.5 });
const heroStats = document.querySelector('.hero-stats');
if (heroStats) heroObserver.observe(heroStats);

// ── INIT ──
document.addEventListener('DOMContentLoaded', () => {
  applyConfig();
});
