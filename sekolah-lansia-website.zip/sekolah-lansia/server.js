/**
 * ============================================
 * SEKOLAH LANSIA BAHAGIA — BACKEND SERVER
 * Node.js + Express + JSON file database
 * ============================================
 * Install: npm install express cors multer uuid
 * Run:     node server.js
 * Port:    3000
 */

const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_DIR = path.join(__dirname, 'data');
const UPLOAD_DIR = path.join(__dirname, 'public', 'uploads');

// ── MIDDLEWARE ──
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));
app.use('/uploads', express.static(UPLOAD_DIR));

// ── DB HELPERS ──
function readDB(name) {
  const file = path.join(DB_DIR, name + '.json');
  if (!fs.existsSync(file)) return [];
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return []; }
}

function writeDB(name, data) {
  fs.writeFileSync(path.join(DB_DIR, name + '.json'), JSON.stringify(data, null, 2));
}

function readConfig() {
  const file = path.join(DB_DIR, 'config.json');
  if (!fs.existsSync(file)) return defaultConfig();
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return defaultConfig(); }
}

function writeConfig(data) {
  fs.writeFileSync(path.join(DB_DIR, 'config.json'), JSON.stringify(data, null, 2));
}

function defaultConfig() {
  return {
    siteName: 'Sekolah Lansia Bahagia',
    brandText: 'Sekolah Lansia',
    tagline: 'Bersama menuju hari tua yang bermakna, bahagia, dan penuh kasih sayang.',
    heroBadge: '✦ Bersama Lebih Bermakna ✦',
    heroTitle: 'Sekolah Lansia<br><em>Bahagia</em>',
    heroSubtitle: 'Tempat belajar, berkreasi, dan berbagi kebahagiaan<br>bagi para lansia tercinta',
    sambutanTeks: 'Selamat datang di Sekolah Lansia Bahagia...',
    kepalaNama: 'Dr. Siti Rahayu, M.Kes',
    kepalaJabatan: 'Kepala Sekolah Lansia Bahagia',
    visiTeks: 'Menjadi pusat pembelajaran dan pemberdayaan lansia yang terdepan di Indonesia.',
    misiTeks: 'Menyelenggarakan program pendidikan yang relevan\nMemfasilitasi kegiatan sosial dan budaya',
    alamatTeks: 'Jl. Sejahtera No. 45, Jakarta Selatan 12345',
    teleponTeks: '+62 21 555-666',
    emailTeks: 'info@sekolahlansia.id',
    jamTeks: 'Senin – Sabtu: 07.00 – 15.00 WIB',
    igLink: 'https://instagram.com/',
    ytLink: 'https://youtube.com/',
    waLink: 'https://wa.me/6221555666',
    fbLink: 'https://facebook.com/',
    emailLink: 'mailto:info@sekolahlansia.id',
    primaryColor: '#2E7D5B',
    goldColor: '#C8962A',
    mapsUrl: ''
  };
}

// ── ENSURE DIRS ──
[DB_DIR, UPLOAD_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// ============================
// AUTH ENDPOINTS
// ============================
app.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body;
  const users = readDB('users');
  const admin = users.find(u => u.username === username && u.password === password);
  if (!admin && username === 'admin' && password === 'lansia2024') {
    return res.json({ success: true, token: 'admin-token-' + Date.now(), role: 'superadmin' });
  }
  if (admin) return res.json({ success: true, token: 'token-' + admin.id, role: admin.role });
  res.status(401).json({ success: false, message: 'Username atau password salah' });
});

app.post('/api/auth/change-password', (req, res) => {
  const { oldPassword, newPassword } = req.body;
  // Simple: store new admin password in db
  writeDB('adminpass', [{ password: newPassword, updatedAt: new Date().toISOString() }]);
  res.json({ success: true, message: 'Password berhasil diubah' });
});

// ============================
// CONFIG / SITE SETTINGS
// ============================
app.get('/api/config', (req, res) => {
  res.json(readConfig());
});

app.put('/api/config', (req, res) => {
  const current = readConfig();
  const updated = { ...current, ...req.body, updatedAt: new Date().toISOString() };
  writeConfig(updated);
  res.json({ success: true, data: updated });
});

// ============================
// REGISTRASI / PENDAFTAR
// ============================
app.get('/api/registrasi', (req, res) => {
  let data = readDB('registrasi');
  const { search, limit } = req.query;
  if (search) data = data.filter(r => r.nama?.toLowerCase().includes(search.toLowerCase()) || r.telp?.includes(search));
  if (limit) data = data.slice(-parseInt(limit));
  res.json({ success: true, total: data.length, data: data.reverse() });
});

app.post('/api/registrasi', (req, res) => {
  const data = readDB('registrasi');
  const record = {
    id: 'SLB-' + new Date().getFullYear() + '-' + String(Date.now()).slice(-4),
    ...req.body,
    status: 'pending',
    createdAt: new Date().toISOString(),
    tanggal: new Date().toISOString().split('T')[0]
  };
  data.push(record);
  writeDB('registrasi', data);
  res.status(201).json({ success: true, data: record, message: 'Pendaftaran berhasil!' });
});

app.put('/api/registrasi/:id', (req, res) => {
  let data = readDB('registrasi');
  const idx = data.findIndex(r => r.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Data tidak ditemukan' });
  data[idx] = { ...data[idx], ...req.body, updatedAt: new Date().toISOString() };
  writeDB('registrasi', data);
  res.json({ success: true, data: data[idx] });
});

app.delete('/api/registrasi/:id', (req, res) => {
  let data = readDB('registrasi');
  data = data.filter(r => r.id !== req.params.id);
  writeDB('registrasi', data);
  res.json({ success: true, message: 'Data dihapus' });
});

// ============================
// ABSENSI
// ============================
app.get('/api/absensi', (req, res) => {
  let data = readDB('absensi');
  const { tanggal, nama } = req.query;
  if (tanggal) data = data.filter(a => a.tanggal === tanggal);
  if (nama) data = data.filter(a => a.nama?.toLowerCase().includes(nama.toLowerCase()));
  res.json({ success: true, total: data.length, data: data.reverse() });
});

app.post('/api/absensi', (req, res) => {
  const data = readDB('absensi');
  const now = new Date();
  const record = {
    id: uuidv4(),
    ...req.body,
    waktu: now.toISOString(),
    tanggal: now.toISOString().split('T')[0]
  };
  data.push(record);
  writeDB('absensi', data);
  res.status(201).json({ success: true, data: record, message: 'Absensi tercatat!' });
});

app.delete('/api/absensi/:id', (req, res) => {
  let data = readDB('absensi');
  data = data.filter(a => a.id !== req.params.id);
  writeDB('absensi', data);
  res.json({ success: true, message: 'Absensi dihapus' });
});

app.get('/api/absensi/stats/today', (req, res) => {
  const data = readDB('absensi');
  const today = new Date().toISOString().split('T')[0];
  const todayData = data.filter(a => a.tanggal === today);
  res.json({
    success: true,
    total: todayData.length,
    sehat: todayData.filter(a => a.health === 'sehat').length,
    kurang: todayData.filter(a => a.health === 'kurang').length,
    sakit: todayData.filter(a => a.health === 'sakit').length,
    data: todayData
  });
});

// ============================
// AGENDA
// ============================
app.get('/api/agenda', (req, res) => {
  let data = readDB('agenda');
  const { upcoming } = req.query;
  if (upcoming === '1') {
    const today = new Date().toISOString().split('T')[0];
    data = data.filter(a => a.tgl >= today).sort((a, b) => a.tgl.localeCompare(b.tgl));
  }
  res.json({ success: true, total: data.length, data });
});

app.post('/api/agenda', (req, res) => {
  const data = readDB('agenda');
  const record = { id: uuidv4(), ...req.body, createdAt: new Date().toISOString() };
  data.push(record);
  writeDB('agenda', data);
  res.status(201).json({ success: true, data: record });
});

app.put('/api/agenda/:id', (req, res) => {
  let data = readDB('agenda');
  const idx = data.findIndex(a => a.id === req.params.id);
  if (idx === -1) return res.status(404).json({ success: false, message: 'Agenda tidak ditemukan' });
  data[idx] = { ...data[idx], ...req.body };
  writeDB('agenda', data);
  res.json({ success: true, data: data[idx] });
});

app.delete('/api/agenda/:id', (req, res) => {
  let data = readDB('agenda');
  data = data.filter(a => a.id !== req.params.id);
  writeDB('agenda', data);
  res.json({ success: true });
});

// ============================
// GALLERY
// ============================
app.get('/api/gallery', (req, res) => {
  let data = readDB('gallery');
  const { kat } = req.query;
  if (kat && kat !== 'all') data = data.filter(g => g.kat === kat);
  res.json({ success: true, total: data.length, data });
});

app.post('/api/gallery', (req, res) => {
  const data = readDB('gallery');
  const record = { id: uuidv4(), ...req.body, createdAt: new Date().toISOString() };
  data.push(record);
  writeDB('gallery', data);
  res.status(201).json({ success: true, data: record });
});

app.delete('/api/gallery/:id', (req, res) => {
  let data = readDB('gallery');
  const item = data.find(g => g.id === req.params.id);
  if (item?.src) {
    const filePath = path.join(__dirname, 'public', item.src);
    if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
  }
  data = data.filter(g => g.id !== req.params.id);
  writeDB('gallery', data);
  res.json({ success: true });
});

// ============================
// PROGRAM
// ============================
app.get('/api/program', (req, res) => {
  const data = readDB('program');
  if (!data.length) {
    const defaults = [
      { id: '1', icon: 'fa-brain', color: '#FF7043', bg: '#FFF0E6', name: 'Stimulasi Kognitif', desc: 'Latihan otak, teka-teki, dan aktivitas yang menjaga ketajaman pikiran' },
      { id: '2', icon: 'fa-music', color: '#43A047', bg: '#E8F5E9', name: 'Seni & Budaya', desc: 'Menyanyi, menari, melukis, dan kerajinan tangan bersama' },
      { id: '3', icon: 'fa-heartbeat', color: '#1E88E5', bg: '#E3F2FD', name: 'Kesehatan Holistik', desc: 'Senam lansia, yoga, pemeriksaan kesehatan rutin' },
      { id: '4', icon: 'fa-laptop', color: '#8E24AA', bg: '#F3E5F5', name: 'Literasi Digital', desc: 'Belajar smartphone, media sosial, dan teknologi' },
      { id: '5', icon: 'fa-book-open', color: '#F9A825', bg: '#FFF9C4', name: 'Kajian & Rohani', desc: 'Kajian agama, diskusi, dan kegiatan spiritual' },
      { id: '6', icon: 'fa-camera', color: '#E91E63', bg: '#FCE4EC', name: 'Fotografi & Wisata', desc: 'Wisata edukatif, fotografi, dan dokumentasi momen berharga' },
    ];
    return res.json({ success: true, data: defaults });
  }
  res.json({ success: true, data });
});

app.put('/api/program', (req, res) => {
  writeDB('program', req.body);
  res.json({ success: true });
});

// ============================
// MENU
// ============================
app.get('/api/menu', (req, res) => {
  const data = readDB('menu');
  if (!data.length) {
    return res.json({ success: true, data: [
      { label: 'Beranda', href: '#beranda', active: true },
      { label: 'Tentang', href: '#tentang', active: true },
      { label: 'Program', href: '#program', active: true },
      { label: 'Agenda', href: '#agenda', active: true },
      { label: 'Gallery', href: '#gallery', active: true },
      { label: 'Games', href: '#games', active: true },
      { label: 'Kontak', href: '#kontak', active: true },
      { label: 'Daftar Sekarang', href: '#daftar', active: true },
    ]});
  }
  res.json({ success: true, data });
});

app.put('/api/menu', (req, res) => {
  writeDB('menu', req.body);
  res.json({ success: true });
});

// ============================
// NEWSLETTER
// ============================
app.post('/api/newsletter', (req, res) => {
  const data = readDB('newsletter');
  const { email } = req.body;
  if (!email) return res.status(400).json({ success: false, message: 'Email wajib diisi' });
  if (data.find(n => n.email === email)) return res.json({ success: true, message: 'Email sudah terdaftar' });
  data.push({ id: uuidv4(), email, createdAt: new Date().toISOString() });
  writeDB('newsletter', data);
  res.json({ success: true, message: 'Berhasil berlangganan newsletter!' });
});

app.get('/api/newsletter', (req, res) => {
  res.json({ success: true, data: readDB('newsletter') });
});

// ============================
// CHAT / PESAN
// ============================
app.post('/api/chat', (req, res) => {
  const data = readDB('chat');
  const record = { id: uuidv4(), ...req.body, createdAt: new Date().toISOString(), status: 'unread' };
  data.push(record);
  writeDB('chat', data);
  res.json({ success: true, data: record });
});

app.get('/api/chat', (req, res) => {
  res.json({ success: true, data: readDB('chat').reverse() });
});

// ============================
// DASHBOARD STATS
// ============================
app.get('/api/stats', (req, res) => {
  const registrasi = readDB('registrasi');
  const absensi = readDB('absensi');
  const agenda = readDB('agenda');
  const gallery = readDB('gallery');
  const today = new Date().toISOString().split('T')[0];
  const thisMonth = new Date().toISOString().slice(0, 7);

  const todayAbs = absensi.filter(a => a.tanggal === today);
  const thisMonthReg = registrasi.filter(r => r.createdAt?.startsWith(thisMonth));
  const upcomingAgenda = agenda.filter(a => a.tgl >= today);

  res.json({
    success: true,
    data: {
      totalPendaftar: registrasi.length,
      pendaftarBulanIni: thisMonthReg.length,
      hadirHariIni: todayAbs.length,
      totalAbsensiRecord: absensi.length,
      agendaMendatang: upcomingAgenda.length,
      totalFotoGallery: gallery.length,
    }
  });
});

// ============================
// SERVE FRONTEND
// ============================
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'admin', 'index.html')));

// ============================
// START SERVER
// ============================
app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════╗
║   SEKOLAH LANSIA BAHAGIA — SERVER     ║
╠════════════════════════════════════════╣
║  🌐 Website : http://localhost:${PORT}     ║
║  🔧 Admin   : http://localhost:${PORT}/admin ║
║  📡 API     : http://localhost:${PORT}/api   ║
╚════════════════════════════════════════╝
  `);
});

module.exports = app;
