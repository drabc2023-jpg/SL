# 🌿 Sekolah Lansia Bahagia — Website Full Stack

Website lengkap untuk Sekolah Lansia dengan frontend elegan, admin dashboard, dan backend API.

---

## 📁 Struktur Proyek

```
sekolah-lansia/
├── index.html              ← Halaman utama website
├── server.js               ← Backend Express API
├── package.json
├── admin/
│   └── index.html          ← Dashboard Admin (CMS)
├── public/
│   ├── css/main.css        ← Stylesheet utama
│   ├── js/app.js           ← Logika frontend
│   ├── js/games.js         ← Games (Memory & Quiz)
│   └── images/logo.svg     ← Logo sekolah
└── data/                   ← Database JSON (auto-dibuat)
    ├── registrasi.json
    ├── absensi.json
    ├── agenda.json
    ├── gallery.json
    ├── config.json
    └── ...
```

---

## 🚀 Cara Install & Jalankan

### Lokal (Development)

```bash
# 1. Masuk ke folder proyek
cd sekolah-lansia

# 2. Install dependencies
npm install

# 3. Jalankan server
npm start

# 4. Buka browser
# Website  → http://localhost:3000
# Admin    → http://localhost:3000/admin
```

### Login Admin
- **Username:** `admin`
- **Password:** `lansia2024`

---

## 🌐 Deploy ke Hosting

### Opsi A: Railway (Gratis & Mudah)
1. Buat akun di [railway.app](https://railway.app)
2. Upload folder ini atau hubungkan ke GitHub
3. Railway otomatis detect Node.js
4. Set environment variable: `PORT=3000`
5. Deploy → Dapat URL publik gratis!

### Opsi B: Render.com (Gratis)
1. Push ke GitHub
2. Buat akun di [render.com](https://render.com)
3. New → Web Service → Connect repo
4. Build Command: `npm install`
5. Start Command: `npm start`
6. Deploy!

### Opsi C: VPS / cPanel (Shared Hosting)
```bash
# Upload semua file ke hosting
# Install Node.js di server
# Gunakan PM2 agar server tetap jalan:
npm install -g pm2
pm2 start server.js --name "sekolah-lansia"
pm2 save
pm2 startup
```

### Opsi D: Netlify / Vercel (Frontend Only)
Jika tidak butuh backend, upload hanya:
- `index.html`
- `admin/index.html`
- `public/` folder

Data akan tersimpan di `localStorage` browser.

---

## ✨ Fitur Lengkap

### 🌐 Website Utama
- ✅ Hero section animasi
- ✅ Sambutan Kepala Sekolah
- ✅ Visi, Misi & Nilai
- ✅ Program Unggulan (6 program)
- ✅ Agenda / Jadwal Kegiatan
- ✅ Gallery Foto dengan lightbox & filter
- ✅ Video YouTube section
- ✅ Mini Games (Memory Match + Tebak Kata)
- ✅ Absensi Digital
- ✅ Formulir Pendaftaran 3 langkah
- ✅ Peta Google Maps
- ✅ Kontak & Info Sekolah
- ✅ Live Chat Widget
- ✅ Link: Instagram, YouTube, WhatsApp, Email
- ✅ Newsletter subscription
- ✅ Footer lengkap
- ✅ Responsive mobile

### 🔧 Admin Dashboard
- ✅ Login dengan password
- ✅ Dashboard statistik real-time
- ✅ Kelola Pendaftar (view, hapus, export CSV)
- ✅ Kelola Absensi (filter tanggal, export)
- ✅ Kelola Agenda (tambah, edit, hapus)
- ✅ Kelola Gallery (upload foto, hapus)
- ✅ Edit Sambutan & Visi Misi
- ✅ Edit Program Unggulan
- ✅ Pengaturan Sosial Media
- ✅ Ganti Tema & Warna website
- ✅ Edit Nama & Info Sekolah
- ✅ Edit Kontak & Lokasi
- ✅ Pengaturan Menu Navigasi
- ✅ Ganti Password Admin

### 📡 Backend API
- ✅ `GET/PUT /api/config` — Pengaturan website
- ✅ `GET/POST/PUT/DELETE /api/registrasi` — Pendaftar
- ✅ `GET/POST/DELETE /api/absensi` — Absensi
- ✅ `GET/POST/PUT/DELETE /api/agenda` — Agenda
- ✅ `GET/POST/DELETE /api/gallery` — Gallery
- ✅ `GET/PUT /api/program` — Program
- ✅ `GET/PUT /api/menu` — Menu navigasi
- ✅ `POST/GET /api/newsletter` — Newsletter
- ✅ `POST/GET /api/chat` — Pesan chat
- ✅ `GET /api/stats` — Statistik dashboard

---

## 🎨 Kustomisasi

### Ganti Warna Tema
Di Admin → Tema & Warna → Pilih warna utama dan aksen

### Ganti Foto Gallery
Di Admin → Gallery → Upload Foto Baru

### Edit Konten
Semua teks, nama, alamat, sosmed bisa diubah di Admin tanpa coding.

### Ganti Logo
Ganti file `public/images/logo.svg` dengan logo sekolah Anda.

---

## 📱 Responsive
Website tampil sempurna di:
- Desktop (1200px+)
- Tablet (768px–1024px)
- Mobile (320px–767px)

---

## 🛡️ Keamanan
- Admin login terproteksi password
- Password dapat diganti di dashboard
- CORS enabled untuk API
- Data tersimpan aman di server (JSON files)

---

*Dibuat dengan ❤️ untuk para lansia tercinta Indonesia*
